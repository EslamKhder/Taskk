/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sport;

/**
 *
 * @author MBR
 */
public interface SportDaoInterface {
    public int addChild(Child child, String nameSport, Captain captain);
    public int deleteChild(int idchild);  
    public int removeChild(int idChild);
}
