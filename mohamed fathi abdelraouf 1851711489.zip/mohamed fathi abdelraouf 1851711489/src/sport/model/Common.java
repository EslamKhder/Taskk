/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sport.model;

/**
 *
 * @author MBR
 */
public class Common {
    public static int id = 0;
    
    private String name;

    public Common() {
    }

    public int getId() {
        return id;
    }

    public void setId() {
        ++id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Common{" + "id=" + id + ", name=" + name + '}';
    }
    
    
    
}
