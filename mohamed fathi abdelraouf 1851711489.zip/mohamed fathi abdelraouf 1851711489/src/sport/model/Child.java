/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sport.model;

/**
 *
 * @author MBR
 */
public class Child extends Common{
    
    private int age;
    
    private int myid;
    
    private String address;

    public Child() {
    }

    public int getmy() {
        return myid;
    }

    public int getAge() {
        return age;
    }
   
    

    public void setAge(int age) {
        this.age = age;
    }
    public void myId(int id) {
        this.age = age;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Override
    public String toString() {
        return "Child{" + "age=" + age + ", address=" + address + '}' + "    id: " + super.getId() + "  name: "+ super.getName();
    }
    
    
    
}
