/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sport;

import java.util.Scanner;
import sport.Controller.SportController;
import sport.files.StoreData;
import sport.model.Captain;
import sport.model.Child;
import sport.model.Groub;

/**
 *
 * @author MBR
 */
public class SportApp {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        SportController controller = new SportController();
        StoreData data = new StoreData();
        int i = 1;
        do {
            System.out.println("1 - Add Child");
            System.out.println("2 - Remove Child");
            System.out.println("3 - Store Data In File");
            System.out.println("4 - Exit");
            int res = 0;
            try {
                res = scanner.nextInt();
                switch (res) {
                    case 1:
                        System.out.println("Enter Id Of Child : ");
                        int idch = scanner.nextInt();
                        System.out.println("Enter Type of Sport : ");
                        String sportName = scanner.next();
                        System.out.println("Enter Name Of Child : ");
                        String name = scanner.next();
                        System.out.println("Enter Age Of Child : ");
                        int age = scanner.nextInt();
                        System.out.println("Enter Address Of Child : ");
                        String address = scanner.next();
                        Child child = new Child();
                        child.myId(idch);
                        child.setName(name);
                        child.setAge(age);
                        child.setAddress(address);

                        System.out.println("Enter Name Of Captain : ");
                        String nameCaptain = scanner.next();
                        System.out.println("Enter Phone Of Captain : ");
                        String phoneCaptain = scanner.next();
                        System.out.println("Enter Address Of Captain : ");
                        String addressCaptain = scanner.next();
                        Captain ca = new Captain();
                        ca.setId();
                        ca.setName(nameCaptain);
                        ca.setPhone(phoneCaptain);
                        ca.setAddress(addressCaptain);
                        int reslu = controller.addChild(child, sportName, ca, idch);
                        if (reslu == 1) {
                            System.out.println("Success Added");
                        } else {
                            System.out.println("Check your input data");
                        }
                        break;
                    case 2:
                        System.out.println("Enter Id Of Child : ");
                        int id = scanner.nextInt();
                        int myRes = controller.removeChild(id);
                        if (myRes == 1) {
                            System.out.println("Success Delete !");
                        } else {
                            System.out.println("Id Doesn't Exist");
                        }
                        break;
                    case 3:
                        data.Store();
                        break;
                    case 4:
                        System.out.println("Thanks For You");
                        i = 0;
                    default:
                        System.out.println("Invalid Choose");
                }
            } catch (Exception e) {
                System.out.println("Invalid Choose");
                i = 0;
            }

        } while (i == 1);

    }

}
