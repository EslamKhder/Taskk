/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sport;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author MBR
 */
public class Testing {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        SportController controller = new SportController();
        StoreData data = new StoreData();
        int i = 1;
        List<String> list = new ArrayList<>();
        do {
            System.out.println("1 - Add Child");
            System.out.println("2 - Remove Child");
            System.out.println("3 - Store Data In File");
            System.out.println("4 - Exit");
            int res = 0;
            try {
                res = scanner.nextInt();
                switch (res) {
                    case 1:
                        System.out.println("Enter Id Of Child : ");
                        int idch = scanner.nextInt();
                        
                        list.add("id Child : " + idch);
                        System.out.println("Enter Type of Sport : ");
                        String sportName = scanner.next();
                        list.add("Type of Sport : " + sportName);
                        System.out.println("Enter Name Of Child : ");
                        String name = scanner.next();
                        list.add("Name Of Child : " + name);
                        System.out.println("Enter Age Of Child : ");
                        int age = scanner.nextInt();
                        list.add("Age Of Child : " + age);
                        System.out.println("Enter Address Of Child : ");
                        String address = scanner.next();
                        list.add("Address Of Child : " + address);
                        Child child = new Child();
                        child.myId(idch);
                        child.setName(name);
                        child.setAge(age);
                        child.setAddress(address);

                        list.add("Captain");
                        System.out.println("Enter Name Of Captain : ");
                        String nameCaptain = scanner.next();
                        list.add("Name Of Captain  : " + nameCaptain);
                        System.out.println("Enter Phone Of Captain : ");
                        String phoneCaptain = scanner.next();
                        list.add("Phone Of Captain  : " + phoneCaptain);
                        System.out.println("Enter Address Of Captain : ");
                        String addressCaptain = scanner.next();
                        list.add("Address Of Captain  : " + address);
                        Captain ca = new Captain();
                        ca.setId();
                        ca.setName(nameCaptain);
                        ca.setPhone(phoneCaptain);
                        ca.setAddress(addressCaptain);
                        StoreData.Store(list);
                        int reslu = controller.addChild(child, sportName, ca, idch);
                        if (reslu == 1) {
                            System.out.println("Success Fail Id Is Exist");
                        } else {
                            System.out.println("Check your input data");
                        }
                        break;
                    case 2:
                        System.out.println("Enter Id Of Child : ");
                        int id = scanner.nextInt();
                        int myRes = controller.removeChild(id);
                        if (myRes == 1) {
                            System.out.println("Success Delete !");
                        } else {
                            System.out.println("Id Doesn't Exist");
                        }
                        break;
                    case 3:
                        System.out.println("Success Stored");
                        break;
                    case 4:
                        System.out.println("Thanks For You");
                        i = 0;
                    default:
                        System.out.println("Invalid Choose");
                }
            } catch (Exception e) {
                System.out.println("Invalid Choose");
                i = 0;
            }

        } while (i == 1);

    }

}
