/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sport;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import sport.SportController;

/**
 *
 * @author MBR
 */
public class StoreData {

    private SportController sportController = new SportController();

    public static void Store(List<String> valus) {

        try {
            FileWriter fileWriter = new FileWriter("Sportt.txt");
                            PrintWriter printWriter = new PrintWriter(fileWriter);

            for (int i = 0; i < valus.size(); i++) {
                
                printWriter.printf(valus.get(i) + "\n");
                

            }
            printWriter.close();
        } catch (IOException e) {
            System.err.println("===========> " + e.toString());
        }
    }

}
