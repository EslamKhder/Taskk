/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sport;

import sport.SportController;
import static sport.SportController.sport;

/**
 *
 * @author MBR
 */
public class SportDaoImpl implements SportDaoInterface{

    private int res = 0;
    
    @Override
     public int addChild(Child child, String nameSport, Captain captain) {

        int res ;
        if (sport.size() != 0) {
            for (int i = 0; i < sport.size(); i++) {
                if (sport.get(i).getName().equalsIgnoreCase(nameSport)) {
                    res = sport.get(i).addGroup(child, captain);
                    return res;
                }
            }
        } else {
            Sport s = new Sport();
                    s.setId();
                    s.setName(nameSport);
                    Groub g = new Groub();
                    g.setId();
                    g.setCaptain(captain);
                    g.addChild(child);
                    s.addGroup(child, captain);
                    sport.add(s);
        }
        return 1;
    }

    @Override
    public int deleteChild(int idchild){
        for (int i = 0; i < sport.size(); i++) {
            for (int j = 0; j < sport.get(i).getGroubs().size(); j++) {
                for (int k = 0; k < sport.get(i).getGroubs().get(j).getChilds().size(); k++) {
                    Child c = sport.get(i).getGroubs().get(j).getChilds().get(k);
                    if (c.getId() == idchild) {
                        sport.get(i).getGroubs().get(j).getChilds().remove(c);
                        res = 1;
                        break;
                    }
                    if(res == 1) break;
                }
            }
            if(res == 1) break;
        }
        return res;
    }
    public int removeChild(int idChild){
        for (int i = 0; i < SportController.ids.size(); i++) {
            if(SportController.ids.get(i) == idChild){
                return 1;
            }
        }
        return 0;
    }
    
}
