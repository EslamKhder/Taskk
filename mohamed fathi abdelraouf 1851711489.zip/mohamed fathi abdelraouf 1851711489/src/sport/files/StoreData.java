/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sport.files;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import sport.Controller.SportController;

/**
 *
 * @author MBR
 */
public class StoreData {

    private SportController sportController = new SportController();

    public void Store() {
        try {
            File myObj = new File("Sportt.txt");
            if (myObj.createNewFile()) {
                for (int i = 0; i < 10; i++) {
                    FileWriter myWriter = new FileWriter("Sportt.txt");
                    myWriter.write(SportController.sport.get(i).getId());
                    myWriter.write(SportController.sport.get(i).getName());
                    myWriter.write(SportController.sport.get(i).getGroubs().toString());
                    myWriter.write(SportController.sport.get(i).getGroubs().get(i).getChilds().toString());
                    myWriter.close();
                }

            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("Successfully wrote to the file.");
    }

}
