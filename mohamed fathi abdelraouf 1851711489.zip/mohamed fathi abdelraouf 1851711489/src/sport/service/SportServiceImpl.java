/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sport.service;

import sport.dao.SportDaoImpl;
import sport.dao.SportDaoInterface;
import sport.model.Captain;
import sport.model.Child;

/**
 *
 * @author MBR
 */
public class SportServiceImpl implements SportServiceInterface{

    private SportDaoInterface interface1 = new SportDaoImpl();
    
    @Override
    public int addChild(Child child, String nameSport, Captain captain) {
        return interface1.addChild(child, nameSport, captain);
    }

    @Override
    public int deleteChild(int idchild) {
        return interface1.deleteChild(idchild);
    }

    @Override
    public int removeChild(int idChild) {
        return interface1.removeChild(idChild);
    }

 
}
