package sport;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author MBR
 */
public class SportController {

    public static List<Sport> sport = new ArrayList<>();
    public static List<Integer> ids = new ArrayList<>();
    
    private int res = 0;
    private SportServiceInterface interface1 = new SportServiceImpl();

    public int addChild(Child child, String nameSport, Captain captain,Integer id) {
        ids.add(id);
        return interface1.addChild(child, nameSport, captain);
    }
    public int removeChild(Integer idchild){
        if(ids.contains(idchild)){
            return 1;
        }
        return 0;
    }
}
