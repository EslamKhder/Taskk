/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sport;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author MBR
 */
public class Groub extends Common {

    private  int size;

    private static int numGroub = 0;

    private List<Child> childs;

    private Captain captain;

    public int addChild(Child child) {
        size = childs.size();
        System.out.println("sizze :::: " +size);
        if (size != 5) {
            if (childs.size() != 0) {
                for (int i = 0; i < childs.size(); i++) {
                    if (childs.get(i).getId() - 1 == child.getId() ) {
                        return -1;
                    } else if (child.getName().equalsIgnoreCase(childs.get(i).getName())) {
                        return 0;
                    }
                }
                childs.add(child);
            } else {
                childs.add(child);
            }
            return 1;
        } else {
            return -4;
        }
    }

    public Groub() {
        childs = new ArrayList<>();
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public List<Child> getChilds() {
        return childs;
    }

    public void setChilds(List<Child> childs) {
        this.childs = childs;
    }

    public Captain getCaptain() {
        return captain;
    }

    public void setCaptain(Captain captain) {
        this.captain = captain;
    }

    @Override
    public String toString() {
        return "Groub{" + "size=" + size + ", childs=" + childs + ", captain=" + captain + '}';
    }

    public int getNumGroub() {
        return numGroub;
    }

    public void setNumGroub() {
        this.numGroub++;
    }

    public void setNameGr() {
        super.setName("Group " + ++numGroub);
        System.out.println("Name Of Group : " + super.getName());
    }

}
