/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sport;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author MBR
 */
public class Sport extends Common {

    private List<Groub> groubs;

    
    public int addGroup(Child child, Captain captain) {
        int res = 0;
        //System.out.println("Gro: " + groubs.size());
        if (groubs.size() == 0) {
            Groub g = new Groub();
            g.addChild(child);
            g.setCaptain(captain);
            g.setNameGr();
            groubs.add(g);
            res = 1;
        } else {
            int size = groubs.size();
            res = groubs.get(size - 1).addChild(child);
            
            if (res == -4) {
                System.out.println("fin");
                Groub g = new Groub();
                g.addChild(child);
                g.setCaptain(captain);
                g.setNameGr();
                groubs.add(g);
            } else if(res == 0) {
                res = 0;
            } else {
                res = 1;
            }
        }
        return res;
    }

    public Sport() {
        groubs = new ArrayList<>();
    }

    public List<Groub> getGroubs() {
        return groubs;
    }

    public void setGroubs(List<Groub> groubs) {
        this.groubs = groubs;
    }

    @Override
    public String toString() {
        return "Sport{" + "groubs=" + groubs + '}';
    }

}
