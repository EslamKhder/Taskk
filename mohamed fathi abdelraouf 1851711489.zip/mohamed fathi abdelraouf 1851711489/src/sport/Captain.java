/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sport;

/**
 *
 * @author MBR
 */
public class Captain extends Common{
    
    private int age;
    
    private String phone;
    
    private String address;

    public Captain() {
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Override
    public String toString() {
        return "Captain{" + "age=" + age + ", phone=" + phone + ", address=" + address + '}';
    }
    
    
    
}
